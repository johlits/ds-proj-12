#!/bin/sh

CLASSPATH="$CLASSPATH":./Editor:./Sim:./images:.:.
export CLASSPATH

javac *.java ./Editor/*.java ./Sim/*.java

