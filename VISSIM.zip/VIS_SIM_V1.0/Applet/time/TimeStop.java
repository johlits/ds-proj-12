package time;

/**
 * Class representing a TimeStop Exception
 *
 * @author <a href="mailto:jnm@doc.ic.ac.uk">Jeff Magee</a>
 */
public class TimeStop extends Exception {

    public TimeStop(String s) {super(s);}
    public TimeStop() {super();}

}
