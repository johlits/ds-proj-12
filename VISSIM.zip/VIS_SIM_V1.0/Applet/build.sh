#!/bin/sh

CLASSPATH="$CLASSPATH":.
export CLASSPATH

javac *.java

