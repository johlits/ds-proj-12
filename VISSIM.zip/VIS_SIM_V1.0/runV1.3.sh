#!/bin/sh

CLASSPATH="$CLASSPATH":./Editor:./Sim:./Utils:./images:./XML:.
export CLASSPATH

/usr/lib/jdk1.3/bin/java Main &