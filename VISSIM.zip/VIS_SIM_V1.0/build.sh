#!/bin/sh

CLASSPATH="$CLASSPATH":./Editor:./Sim:./images:.:.
export CLASSPATH

/usr/java/j2sdk1.4.0_01/bin/javac *.java ./Editor/*.java ./Sim/*.java

