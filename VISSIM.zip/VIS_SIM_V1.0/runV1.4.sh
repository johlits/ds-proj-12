#!/bin/sh

CLASSPATH="$CLASSPATH":./Editor:./Sim:./Utils:./images:./XML:.
export CLASSPATH

java Main &

