cd ..
zip -r VISSIM.zip VIS_SIM_V1.0
mv VISSIM.zip VIS_SIM_V1.0

