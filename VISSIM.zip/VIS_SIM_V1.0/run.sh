#!/bin/sh

CLASSPATH="$CLASSPATH":./Editor:./Sim:./Utils:./images:./XML:.
export CLASSPATH

/usr/java/j2sdk1.4.0_01/bin/java Main &