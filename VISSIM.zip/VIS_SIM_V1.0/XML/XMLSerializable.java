package XML;

import java.io.*;

public interface XMLSerializable {

    String getXMLName();
    XMLElement saveSelf();
    void saveChilds(XMLSaver saver);
    void loadSelf(XMLElement element);
    void loadChilds(XMLLoader loader);
    //boolean childName(String tag);
}
