mv THESPECFILE ../Applet/
cd ../Applet/
jar cf THEJARNAME *.class THESPECFILE Utils XML time
rm THESPECFILE
mv THEJARNAME ../AppletSaves
cd ../AppletSaves
rm THESPECFILE.sh
rm THESPECFILE.bat