chmod u+x $1
$1
